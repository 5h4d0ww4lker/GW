
<!-- BEGIN STEPS -->

<!-- END STEPS -->

<!-- BEGIN CLIENTS -->
<div class="row-fluid margin-bottom-40">
    <div class="span3">
        <h2><a href="#">Our Sponsors</a></h2>
        <p>Advertise Your Company Here.</p>
    </div>
    <div class="span9">
        <ul class="bxslider1 clients-list">
            <li>
                <a href="#">
                    <img src="<?php echo base_url(); ?>advert/sefe.jpg" alt="" id="adv"  id="adv"/>
                    <img src="<?php echo base_url(); ?>advert/sefe.jpg" class="color-img" alt="" id="adv" id="adv"/>
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url(); ?>advert/us.jpg" alt="" id="adv" id="adv" />
                    <img src="<?php echo base_url(); ?>advert/us.jpg" class="color-img" alt="" id="adv" id="adv" />
                </a>
            </li>
            <li>
                <a href="#">
                    <img src="<?php echo base_url(); ?>advert/advertise here.jpg" alt="" id="adv" />
                    <img src="<?php echo base_url(); ?>advert/advertise here.jpg" class="color-img" alt="" id="adv" />
                </a>
            </li>
            
        </ul>
    </div>
</div>
<!-- END CLIENTS -->
</div>
<!-- END CONTAINER -->