<div class="fullwidthbanner-container slider-main margin-bottom-10">
    <div class="fullwidthabnner">
        <ul id="revolutionul" style="display:none;">
            <!-- THE FIRST SLIDE -->
            <li data-transition="fade" data-slotamount="8" data-masterspeed="700" data-delay="9400" data-thumb="<?php echo base_url(); ?>assets/img/sliders/revolution/thumbs/thumb2.jpg">
                <!-- THE MAIN IMAGE IN THE FIRST SLIDE -->
                <img src="<?php echo base_url(); ?>advert/bg.jpg" alt="">

                <div class="caption lft slide_title slide_item_left"
                     data-x="0"
                     data-y="125"
                     data-speed="400"
                     data-start="1500"
                     data-easing="easeOutExpo">
                    Need to be near to your <br><br>Customers ?<br><br><br>
                </div>
                
               
                <a class="caption lft btn green slide_btn slide_item_left" href="<?php echo site_url('hag22673627bet8001niki1base5621ac/register') ?>"   
                   data-x="0"
                   data-y="290"
                   data-speed="400"
                   data-start="3000"
                   data-easing="easeOutExpo">
                    Register Now!
                </a>
                <div class="caption lfb"
                     data-x="640"
                     data-y="55"
                     data-speed="700"
                     data-start="1000"
                     data-easing="easeOutExpo"  >
                    <img src="<?php echo base_url(); ?>advert/1.png" alt="Image 1">
                </div>
            </li>

            <!-- THE SECOND SLIDE -->
            <li data-transition="fade" data-slotamount="7" data-masterspeed="300" data-delay="9400" data-thumb="<?php echo base_url(); ?>assets/img/sliders/revolution/thumbs/thumb2.jpg">
                <img src="<?php echo base_url(); ?>advert/bg.jpg" alt="">
                <div class="caption lfl slide_title slide_item_left"
                     data-x="0"
                     data-y="145"
                     data-speed="400"
                     data-start="3500"
                     data-easing="easeOutExpo">
                    Search Places For Free!
                </div>
                <div class="caption lfl slide_subtitle slide_item_left"
                     data-x="0"
                     data-y="200"
                     data-speed="400"
                     data-start="4000"
                     data-easing="easeOutExpo">
                    Book and Reserve at ur comfort.
                </div>
                
                <div class="caption lfr slide_item_right"
                     data-x="635"
                     data-y="105"
                     data-speed="1200"
                     data-start="1500"
                     data-easing="easeOutBack">
                    <img src="<?php echo base_url(); ?>advert/5.jpg" width= "480" height ="380"  alt="Image 1">
                </div>
               
               
               
               
               

            </li>



                <div class="caption lft start"
                     data-x="850"
                     data-y="55"
                     data-speed="400"
                     data-start="2400"
                     data-easing="easeOutBack"  >
                    <img src="<?php echo base_url(); ?>assets/img/sliders/revolution/iphone_right.png" alt="Image 3">
                </div>
            </li>
        </ul>
        <div class="tp-bannertimer tp-bottom"></div>
    </div>
</div>
<!-- END REVOLUTION SLIDER -->
