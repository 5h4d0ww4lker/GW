<!-- BEGIN CONTAINER -->
<div class="container">
    <!-- BEGIN SERVICE BOX -->
    <div class="row-fluid service-box">
        <div class="span12">
            <div class="service-box-heading">
                <em><i class="icon-thumbs-up green"></i></em>
                <span>Welcome to 2hagerbet.com</span>
            </div>

<p> The best hotel searching website in ethiopia. You can find different hotels, restaurants,guest houses and clubs. You can find what ever you want based on your search parameters. This Includes Hotel,Resort,Guest House Basic Information, Room Prices, Available Services,Room Services, Room Prices, and Also Booking, Contact and Several Services.

Additionally Restaurant Basic Information, Restaurant Menu, Restaurant Special,Other facilities, and Also Table Reservation, Contact and Several Services.

For Clubs and Cultural Places Basic Information, Restaurant Menu, Available Food and Drink Items, Schedules, Days ,Other facilities, and Also Table Reservation, Contact and Several Services.</p>



            <p>You can register your Hotel on our website and create a profile for your Hotel.You can add many informations about your hotel inclluding basic info, room infos, room types, room prices, available food and drink items,available room types other room additional Hotel services and events that comming upon your Hotel.Your customers can see your info in our website and book a room or reserve a table in your Hotel.</p>
        </div>
        
      






    </div>

   

    <!-- BEGIN BLOCKQUOTE BLOCK -->
    <div class="row-fluid quote-v1">
        <div class="span9 quote-v1-inner">
            <span>2hagerbet.com - The Best Known  Accommodation Places Searcher In Ethiopia</span>
        </div>
        <div class="span3 quote-v1-inner text-right">
            <a class="btn-transparent" href="www.facebook.com" target="www.facebook.com"><i class="icon-thumbs-up margin-right-10"></i>Facebook</a>
            <!--<a class="btn-transparent" href="http://themeforest.net/item/metronic-responsive-admin-dashbord-template/4021469"><i class="icon-gift margin-right-10"></i>Purchase 2 in 1</a>-->
        </div>
    </div>
    <!-- END BLOCKQUOTE BLOCK -->

    <div class="clearfix"></div>

    <!-- BEGIN RECENT WORKS -->
    <div class="row-fluid recent-work margin-bottom-40">
        <div class="span3">
            <h2><a href="portfolio.html">Featured Places</a></h2>
            <p>Most preffered places in ethiopia are this. You will Get the most hospitalised services in these hotels than any other Places.Contact Us If you want to add your company in this List.</p>
        </div>
        <div class="span9">
            <ul class="bxslider">
                <li>
                    <em>
                        <img src="<?php echo base_url(); ?>advert/8 (2).jpg"  id="bla" alt="" />
                      
                    </em>
                   <!--  <a class="bxslider-block" href="#">
                        <strong>Jupiter Hotel</strong>
                        <b>jupiterhotels.com</b>
                    </a> -->
                </li>
                <li>
                    <em>
                        <img src="<?php echo base_url(); ?>advert/8 (5).jpg" id="bla" alt="" />
                        
                    </em>
                    <!-- <a class="bxslider-block" href="#">
                        <strong>Inter Continental Hotel</strong>
                        <b>www.intercontinental.com</b>
                    </a> -->
                </li>
                <li>
                    <em>
                        <img src="<?php echo base_url(); ?>advert/8 (3).jpg" id="bla" alt="" />
                        
                    </em>
                   <!--  <a class="bxslider-block" href="#">
                        <strong>Wasamar Hotel</strong>
                        <b>www.wasamar.com</b>
                    </a> -->
                </li>


                 <li>
                    <em>
                        <img src="<?php echo base_url(); ?>advert/8 (4).jpg" id="bla" alt="" />
                        
                    </em>
                   <!--  <a class="bxslider-block" href="#">
                        <strong>Wasamar Hotel</strong>
                        <b>www.wasamar.com</b>
                    </a> -->
                </li>



                <li>
                    <em>
                        <img src="<?php echo base_url(); ?>advert/8 (6).jpg" id="bla" alt="" />
                        
                    </em>
                   <!--  <a class="bxslider-block" href="#">
                        <strong>Wasamar Hotel</strong>
                        <b>www.wasamar.com</b>
                    </a> -->
                </li>


                


            </ul>
        </div>
    </div>
    <!-- END RECENT WORKS -->

    <div class="clearfix"></div>


