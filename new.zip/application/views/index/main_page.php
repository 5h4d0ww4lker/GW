


<!-- BEGIN CONTAINER -->
<div class="container min-hight">
    <!-- BEGIN PRICING OPTION1 -->
    <div class="row-fluid margin-bottom-40">
        <div class="span3 pricing">
            <div class="pricing-head">
                <h3>Begginer <span>Officia deserunt mollitia</span></h3>
                <h4><i>$</i>5<i>.49</i> <span>Per Month</span></h4>
            </div>
            <ul class="pricing-content unstyled">
                <li><i class="icon-tags"></i> At vero eos</li>
                <li><i class="icon-asterisk"></i> No Support</li>
                <li><i class="icon-heart"></i> Fusce condimentum</li>
                <li><i class="icon-star"></i> Ut non libero</li>
                <li><i class="icon-shopping-cart"></i> Consecte adiping elit</li>
            </ul>
            <div class="pricing-footer">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut non libero magna psum olor .</p>
                <a href="#" class="btn theme-btn pull-left">Sign Up</a>
                <a href="#" class="btn theme-btn pull-right">Sign Up</a>
            </div>
        </div>
        <div class="span3 pricing">
            <div class="pricing-head">
                <h3>Pro<span>Officia deserunt mollitia</span></h3>
                <h4><i>$</i>8<i>.69</i> <span>Per Month</span></h4>
            </div>
            <ul class="pricing-content unstyled">
                <li><i class="icon-tags"></i> At vero eos</li>
                <li><i class="icon-asterisk"></i> No Support</li>
                <li><i class="icon-heart"></i> Fusce condimentum</li>
                <li><i class="icon-star"></i> Ut non libero</li>
                <li><i class="icon-shopping-cart"></i> Consecte adiping elit</li>
            </ul>
            <div class="pricing-footer">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut non libero magna psum olor .</p>
                <a href="#" class="btn theme-btn">Sign Up</a>
            </div>
        </div>
        <div class="span3 pricing pricing-active">
            <div class="pricing-head pricing-head-active">
                <h3>Expert <span>Officia deserunt mollitia</span></h3>
                <h4><i>$</i>13<i>.99</i> <span>Per Month</span></h4>
            </div>
            <ul class="pricing-content unstyled">
                <li><i class="icon-tags"></i> At vero eos</li>
                <li><i class="icon-asterisk"></i> No Support</li>
                <li><i class="icon-heart"></i> Fusce condimentum</li>
                <li><i class="icon-star"></i> Ut non libero</li>
                <li><i class="icon-shopping-cart"></i> Consecte adiping elit</li>
            </ul>
            <div class="pricing-footer">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut non libero magna psum olor .</p>
                <a href="#" class="btn theme-btn">Sign Up</a>
            </div>
        </div>
        <div class="span3 pricing">
            <div class="pricing-head">
                <h3>Hi-Tech<span>Officia deserunt mollitia</span></h3>
                <h4><i>$</i>99<i>.00</i> <span>Per Month</span></h4>
            </div>
            <ul class="pricing-content unstyled">
                <li><i class="icon-tags"></i> At vero eos</li>
                <li><i class="icon-asterisk"></i> No Support</li>
                <li><i class="icon-heart"></i> Fusce condimentum</li>
                <li><i class="icon-star"></i> Ut non libero</li>
                <li><i class="icon-shopping-cart"></i> Consecte adiping elit</li>
            </ul>
            <div class="pricing-footer">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut non libero magna psum olor .</p>
                <a href="#" class="btn theme-btn">Sign Up</a>
            </div>
        </div>
    </div>
    <!-- END PRICING OPTION1 -->


    <div class="clearfix margin-bottom-10"></div>


</div>
<!-- END CONTAINER -->


<!-- BEGIN JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
<!-- BEGIN CORE PLUGINS -->
<script src="assets/plugins/jquery-1.10.1.min.js" type="text/javascript"></script>
<script src="assets/plugins/jquery-migrate-1.2.1.min.js" type="text/javascript"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script type="text/javascript" src="assets/plugins/back-to-top.js"></script>
<script type="text/javascript" src="assets/plugins/fancybox/source/jquery.fancybox.pack.js"></script>
<script type="text/javascript" src="assets/plugins/hover-dropdown.js"></script>
<!--[if lt IE 9]>
<script src="assets/plugins/respond.min.js"></script>
<![endif]-->
<!-- END CORE PLUGINS -->
<script src="assets/scripts/app.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function() {
        App.init();

    });
</script>
<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>