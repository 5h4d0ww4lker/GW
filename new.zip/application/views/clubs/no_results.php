

        <!-- BEGIN CONTAINER -->
        <div class="container min-hight">
            <div class="row-fluid">
                <div class="span9">
                    <h2>No results Found</h2>
<p>No results found within the given parameters. Use another search criteria, different search parameters, different key word or check for spelling errors.</p>
<p>Thanx For Choosing 2hagerbet.com</p>
                </div>

                <div class="span3">
                    <h2>Contacts 2hagerbet.com</h2>
                    <address>
                        <strong>Greenware Team</strong><br>
                        0920469132/0911450088<br>
                        Addiss Ababa, Ethiopia<br>

                    </address>
                    <address>
                        <strong>Email</strong><br>
                        <a href="#">he@2hagerbet.com</a><br>
                        <a href="#">2hagerbet@gmail.com</a>
                    </address>


                </div>
            </div>
        </div>
        <!-- END CONTAINER -->
   